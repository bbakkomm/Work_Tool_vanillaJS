import data from './trade.json';
import tradeIn from './tradein';

$(document).ready(function() {
    const tradIn = new tradeIn('.tradein_container', data);
});